class NewController < ApplicationController
  def index
  end

  def new
  end

  def create
  end

  def update
  end

  def edit
  end

  def destroy
  end

  def show
    @new = "salesalesale"
  end
end
