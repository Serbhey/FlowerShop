require 'test_helper'

class NewsDecoratorTest < Draper::TestCase
end
