require 'test_helper'

class NewDecoratorTest < Draper::TestCase
end
